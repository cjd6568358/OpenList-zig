package tool

import (
	"context"
	"fmt"
	"net/url"
	stdpath "path"
	"path/filepath"
	"strings"

	_115 "github.com/OpenListTeam/OpenList/v4/drivers/115"
	_115_open "github.com/OpenListTeam/OpenList/v4/drivers/115_open"
	_123 "github.com/OpenListTeam/OpenList/v4/drivers/123"
	_123_open "github.com/OpenListTeam/OpenList/v4/drivers/123_open"
	"github.com/OpenListTeam/OpenList/v4/drivers/guangyapan"
	"github.com/OpenListTeam/OpenList/v4/drivers/pikpak"
	"github.com/OpenListTeam/OpenList/v4/drivers/thunder"
	"github.com/OpenListTeam/OpenList/v4/drivers/thunder_browser"
	"github.com/OpenListTeam/OpenList/v4/drivers/thunderx"
	"github.com/OpenListTeam/OpenList/v4/internal/conf"
	"github.com/OpenListTeam/OpenList/v4/internal/driver"
	"github.com/OpenListTeam/OpenList/v4/internal/errs"
	"github.com/OpenListTeam/OpenList/v4/internal/fs"
	"github.com/OpenListTeam/OpenList/v4/internal/model"
	"github.com/OpenListTeam/OpenList/v4/internal/op"
	"github.com/OpenListTeam/OpenList/v4/internal/setting"
	"github.com/OpenListTeam/OpenList/v4/internal/task"
	"github.com/OpenListTeam/OpenList/v4/server/common"
	"github.com/google/uuid"
	"github.com/pkg/errors"
)

type DeletePolicy string

const (
	DeleteOnUploadSucceed DeletePolicy = "delete_on_upload_succeed"
	DeleteOnUploadFailed  DeletePolicy = "delete_on_upload_failed"
	DeleteNever           DeletePolicy = "delete_never"
	DeleteAlways          DeletePolicy = "delete_always"
	UploadDownloadStream  DeletePolicy = "upload_download_stream"
)

type AddURLArgs struct {
	URL          string
	DstDirPath   string
	Tool         string
	DeletePolicy DeletePolicy
}

func AddURL(ctx context.Context, args *AddURLArgs) (task.TaskExtensionInfo, error) {
	// check storage
	storage, dstDirActualPath, err := op.GetStorageAndActualPath(args.DstDirPath)
	if err != nil {
		return nil, errors.WithMessage(err, "failed get storage")
	}
	// check is it could upload
	if storage.Config().NoUpload {
		return nil, errors.WithStack(errs.UploadNotSupported)
	}
	// check path is valid
	obj, err := op.Get(ctx, storage, dstDirActualPath)
	if err != nil {
		if !errs.IsObjectNotFound(err) {
			return nil, errors.WithMessage(err, "failed get object")
		}
	} else {
		if !obj.IsDir() {
			// can't add to a file
			return nil, errors.WithStack(errs.NotFolder)
		}
	}
	// try putting url
	if args.Tool == "SimpleHttp" && !isEd2kURL(args.URL) {
		if isSimpleHttpSchemeUnsupported(args.URL) {
			return nil, fmt.Errorf("SimpleHttp tool does not support this URL scheme, please use aria2 or other tools for magnet/ed2k links")
		}
		err = tryPutUrl(ctx, args.DstDirPath, args.URL)
		if err == nil || !errors.Is(err, errs.NotImplement) {
			return nil, err
		}
		// Fallback to creating a download task when storage lacks native PutURL support.
	}

	// ed2k 链接自动路由：如果当前工具不支持 ed2k，自动尝试使用迅雷系工具
	if isEd2kURL(args.URL) {
		if !isEd2kCapableTool(args.Tool) {
			if storageTool := ed2kToolForStorage(storage); storageTool != "" {
				// Prefer the matching native tool when the destination storage supports ed2k.
				args.Tool = storageTool
			} else {
				// Otherwise, try to find an available Thunder-family tool.
				fallbackTool, fallbackName := findEd2kCapableTool()
				if fallbackTool != nil {
					args.Tool = fallbackName
				} else {
					return nil, fmt.Errorf("ed2k protocol is not supported by %s. Please configure and use Thunder/ThunderX/ThunderBrowser for ed2k links", args.Tool)
				}
			}
		}
	}

	// get tool
	tool, err := Tools.Get(args.Tool)
	if err != nil {
		return nil, errors.Wrapf(err, "failed get offline download tool")
	}
	// check tool is ready
	if !tool.IsReady() {
		// try to init tool
		if _, err := tool.Init(); err != nil {
			return nil, errors.Wrapf(err, "failed init offline download tool %s", args.Tool)
		}
	}

	uid := uuid.NewString()
	tempDir := filepath.Join(conf.Conf.TempDir, args.Tool, uid)
	deletePolicy := args.DeletePolicy

	// 如果当前 storage 是对应网盘，则直接下载到目标路径，无需转存
	switch args.Tool {
	case "115 Cloud":
		if _, ok := storage.(*_115.Pan115); ok {
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.Pan115TempDir), uid)
		}
	case "115 Open":
		if _, ok := storage.(*_115_open.Open115); ok {
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.Pan115OpenTempDir), uid)
		}
	case "123 Open":
		if _, ok := storage.(*_123_open.Open123); ok && dstDirActualPath != "/" {
			// directly offline downloading to the root path is not allowed via 123 open platform
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.Pan123OpenTempDir), uid)
		}
	case "123Pan":
		if _, ok := storage.(*_123.Pan123); ok {
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.Pan123TempDir), uid)
		}
	case "PikPak":
		if _, ok := storage.(*pikpak.PikPak); ok {
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.PikPakTempDir), uid)
		}
	case "Thunder":
		if _, ok := storage.(*thunder.Thunder); ok {
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.ThunderTempDir), uid)
		}
	case "ThunderBrowser":
		switch storage.(type) {
		case *thunder_browser.ThunderBrowser, *thunder_browser.ThunderBrowserExpert:
			tempDir = args.DstDirPath
		default:
			tempDir = filepath.Join(setting.GetStr(conf.ThunderBrowserTempDir), uid)
		}
	case "ThunderX":
		if _, ok := storage.(*thunderx.ThunderX); ok {
			tempDir = args.DstDirPath
		} else {
			tempDir = filepath.Join(setting.GetStr(conf.ThunderXTempDir), uid)
		}
	case "GuangYaPan":
		if _, ok := storage.(*guangyapan.GuangYaPan); ok {
			tempDir = args.DstDirPath
		} else {
			tempBase := setting.GetStr(conf.GuangYaPanTempDir)
			if tempBase == "" {
				return nil, errors.New("GuangYaPan temp dir is not set")
			}
			tempDir = filepath.Join(tempBase, uid)
		}
	}

	taskCreator, _ := ctx.Value(conf.UserKey).(*model.User) // taskCreator is nil when convert failed
	t := &DownloadTask{
		TaskExtension: task.TaskExtension{
			Creator: taskCreator,
			ApiUrl:  common.GetApiUrl(ctx),
		},
		Url:          args.URL,
		DstDirPath:   args.DstDirPath,
		TempDir:      tempDir,
		DeletePolicy: deletePolicy,
		Toolname:     args.Tool,
		tool:         tool,
	}
	DownloadTaskManager.Add(t)
	return t, nil
}

func tryPutUrl(ctx context.Context, path, urlStr string) error {
	var dstName string
	u, err := url.Parse(urlStr)
	if err == nil {
		dstName = stdpath.Base(u.Path)
	} else {
		dstName = "UnnamedURL"
	}
	return fs.PutURL(ctx, path, dstName, urlStr)
}

func isSimpleHttpSchemeUnsupported(urlStr string) bool {
	u, err := url.Parse(strings.TrimSpace(urlStr))
	if err != nil || u.Scheme == "" {
		return false
	}
	scheme := strings.ToLower(u.Scheme)
	return scheme != "http" && scheme != "https"
}

// isEd2kURL 检测 URL 是否为 ed2k 协议
func isEd2kURL(urlStr string) bool {
	return strings.HasPrefix(strings.ToLower(urlStr), "ed2k://")
}

func ed2kToolForStorage(storage driver.Driver) string {
	switch toolNameForStorage(storage) {
	case "115 Cloud", "115 Open":
		return toolNameForStorage(storage)
	default:
		return ""
	}
}

func toolNameForStorage(storage driver.Driver) string {
	switch storage.(type) {
	case *_115.Pan115:
		return "115 Cloud"
	case *_115_open.Open115:
		return "115 Open"
	case *_123.Pan123:
		return "123Pan"
	case *_123_open.Open123:
		return "123 Open"
	case *guangyapan.GuangYaPan:
		return "GuangYaPan"
	case *pikpak.PikPak:
		return "PikPak"
	case *thunder.Thunder:
		return "Thunder"
	case *thunderx.ThunderX:
		return "ThunderX"
	case *thunder_browser.ThunderBrowser, *thunder_browser.ThunderBrowserExpert:
		return "ThunderBrowser"
	default:
		return ""
	}
}

// ed2kCapableTools 支持 ed2k 协议的工具列表
var ed2kCapableTools = []string{"115 Cloud", "115 Open", "Thunder", "ThunderX", "ThunderBrowser"}

// ed2kFallbackTools 是当前可用于自动接管 ed2k 任务的工具列表。
var ed2kFallbackTools = []string{"Thunder", "ThunderX", "ThunderBrowser"}

// isEd2kCapableTool 检查工具是否支持 ed2k 协议
func isEd2kCapableTool(toolName string) bool {
	for _, t := range ed2kCapableTools {
		if t == toolName {
			return true
		}
	}
	return false
}

// findEd2kCapableTool 查找一个可用的支持 ed2k 的工具
func findEd2kCapableTool() (Tool, string) {
	for _, name := range ed2kFallbackTools {
		t, err := Tools.Get(name)
		if err != nil {
			continue
		}
		if t.IsReady() {
			return t, name
		}
		// 尝试初始化
		if _, err := t.Init(); err == nil && t.IsReady() {
			return t, name
		}
	}
	return nil, ""
}
